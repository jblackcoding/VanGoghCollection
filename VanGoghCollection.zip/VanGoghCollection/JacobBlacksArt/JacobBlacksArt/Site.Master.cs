﻿//***************************************//
//Name: Jacob Black                      //
//Project: Insert Art ASP.NET            //
//Description: This project is designed  //
//             to take user input and    //
//             display it.               //
//Date: 4/22/2017                        //
//***************************************//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JacobBlacksArt
{
    public partial class Site : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //Bellow are the C# codbehind that will redirect the user upon clinking the links.
        protected void lnkHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        protected void lnkInsert_Click(object sender, EventArgs e)
        {
            Response.Redirect("InsertArt.aspx");
        }

        protected void lnkGridView_Click(object sender, EventArgs e)
        {
            Response.Redirect("GridViewData.aspx");
        }
    }
}