﻿//***************************************//
//Name: Jacob Black                      //
//Project: Insert Art ASP.NET            //
//Description: This project is designed  //
//             to take user input and    //
//             display it.               //
//Date: 4/22/2017                        //
//***************************************//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JacobBlacksArt
{

    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnEnter_Click(object sender, EventArgs e)
        {
            //Redirects the user.
            Response.Redirect("InsertArt.aspx");
        }

        protected void btnStatus_Click(object sender, EventArgs e)
        {
            //The C# uses StringBuilder with system.text to create scripts, I created my JavaScript with it.
            StringBuilder sbScript = new StringBuilder();
            sbScript.Append("<script language='JavaScript' type='text/javascript'>");
            sbScript.Append("alert('The Server Is Online!')");
            sbScript.Append("</script>");
            //This section manages the JavaScript alert for the Callback.
            ScriptManager.RegisterStartupScript(this, this.GetType(), "UseCallback", sbScript.ToString(), false);
        }
    }
}