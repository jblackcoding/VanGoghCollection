﻿//***************************************//
//Name: Jacob Black                      //
//Project: Insert Art ASP.NET            //
//Description: This project is designed  //
//             to take user input and    //
//             display it.               //
//Date: 4/22/2017                        //
//***************************************//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JacobBlacksArt
{
    public partial class GridViewData : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CustomValidator_DateValidate(object source, ServerValidateEventArgs args)
        {
            //Custom validator to insure date is not after today's date
            DateTime minDate = DateTime.Parse("6/16/1000");
            DateTime maxDate = DateTime.Parse(DateTime.Today.ToShortDateString());
            DateTime date;

            args.IsValid = (DateTime.TryParse(args.Value, out date)
                            && date <= maxDate
                            && date >= minDate);

        }


        protected void CustomValidator_YearValidate(object source, ServerValidateEventArgs args)
        {
            //Custom validator for the year created
            if (Convert.ToInt32(args.Value) >= 1800 && Convert.ToInt32(args.Value) <= 1900)
            {
                args.IsValid = true;
            }
            else
            {
                args.IsValid = false;
            }
        }

        protected void lnkInsert_Click(object sender, EventArgs e)
        {
            //Fires the custom validator before inserting data
            Page.Validate();
            if (!Page.IsValid)
            {
                return;
            }
            else
            {
                //If valid, data is inserted into database
                SqlDataSource1.InsertParameters["Name"].DefaultValue =
                    ((TextBox)GridView1.FooterRow.FindControl("txtNameNew")).Text;
                SqlDataSource1.InsertParameters["Location"].DefaultValue =
                    ((TextBox)GridView1.FooterRow.FindControl("txtLocationNew")).Text;
                SqlDataSource1.InsertParameters["Genre"].DefaultValue =
                    ((TextBox)GridView1.FooterRow.FindControl("txtGenreNew")).Text;
                SqlDataSource1.InsertParameters["Media"].DefaultValue =
                    ((TextBox)GridView1.FooterRow.FindControl("txtMediaNew")).Text;
                SqlDataSource1.InsertParameters["Year"].DefaultValue =
                    ((TextBox)GridView1.FooterRow.FindControl("txtYearNew")).Text;
                SqlDataSource1.InsertParameters["Aquired"].DefaultValue =
                    ((TextBox)GridView1.FooterRow.FindControl("txtAquiredNew")).Text;

                SqlDataSource1.Insert();
            }
        }


    }
}