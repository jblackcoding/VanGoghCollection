﻿//***************************************//
//Name: Jacob Black                      //
//Project: Insert Art ASP.NET            //
//Description: This project is designed  //
//             to take user input and    //
//             display it.               //
//Date: 4/22/2017                        //
//***************************************//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;

namespace JacobBlacksArt
{
    public partial class InsertArt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //If not a PostBack do this.
            if (!Page.IsPostBack)
            {
                lblResult.Text = "";
                txtArtwork.Text = "";
                txtYear.Text = "";
                txtLoc.Text = "";
                txtGenre.Text = "";
                txtMedia.Text = "";
                txtDate.Text = "";
                GridViewExample.Visible = true;
            }
            dateValidator.MinimumValue = DateTime.Today.AddYears(-200).ToShortDateString();
            dateValidator.MaximumValue = DateTime.Today.ToShortDateString();
        }

        protected void btnEnter_Click(object sender, EventArgs e)
        {
            //CodeBehind C# to tell application what to do when the btnEnter is clicked.
            string location = txtLoc.Text;
            string genre = txtGenre.Text;
            string media = txtMedia.Text;
            string artwork = txtArtwork.Text;
            string date = txtDate.Text;
            try
            {
                int year = Convert.ToInt32(txtYear.Text);
                //If txtYear is able to be converted to an integer this JavaScript validates the range.
                if (year <= 1800 || year >= 1900)
                {
                    StringBuilder sbScript = new StringBuilder();
                    sbScript.Append("<script language='JavaScript' type='text/javascript'>");
                    sbScript.Append("alert('The year created format is incorrect or not possible. (example: 1889)')");
                    sbScript.Append("</script>");
                    //This section manages the JavaScript alert for the Validation
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "YearValidation", sbScript.ToString(), false);
                }
                else
                {
                    try
                    {
                        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Insert.mdf;Integrated Security=True");
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("Insert into Art(Name, Location, Genre, Media, Year, Aquired) Values('" + artwork + "', '" + location + "', '" + genre + "', '" + media + "', '" + year.ToString() + "', '" + date + "')", conn);
                        lblResult.Text = "You acquired on " + date + " the Artwork piece named '" + artwork + "'. This piece was created in the year " + year.ToString() + ".\n This piece's genre is " + genre + ", and is currently located at the " + location + ".";
                        cmd.ExecuteNonQuery();
                        conn.Close();

                        GridViewExample.Visible = false;
                    }
                    catch
                    {
                        lblResult.Text = "Could not connect to database.";
                    }
                }
            }
            catch
            {
                //This catch block shows a JavaScipt alert if txtYear can not be converted to integer.
                StringBuilder sbScript = new StringBuilder();
                sbScript.Append("<script language='JavaScript' type='text/javascript'>");
                sbScript.Append("alert('The year created format is incorrect or not possible. (example: 1889)')");
                sbScript.Append("</script>");
                //This section manages the JavaScript alert for the Validation
                ScriptManager.RegisterStartupScript(this, this.GetType(), "YearToIntValidation", sbScript.ToString(), false);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            //Redirects user.
            Response.Redirect("Home.aspx");
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtDate.Text = Calendar1.SelectedDate.ToShortDateString();
        }

        protected void btnData_Click(object sender, EventArgs e)
        {
            Response.Redirect("GridViewData.aspx");
        }

        //Buttons to initiate the Linq queries to send the data to the GridView
        protected void btnExampleOne_Click(object sender, EventArgs e)
        {
            IEnumerable<Example> queryResultOne = Example.Examples().Where(example => example.PieceName == "The Starry Night");
            GridViewExample.DataSource = queryResultOne;
            GridViewExample.DataBind();
        }

        protected void btnExampleTwo_Click(object sender, EventArgs e)
        {
            IEnumerable<Example> queryResultTwo = Example.Examples().Where(example => example.PieceName == "Irises");
            GridViewExample.DataSource = queryResultTwo;
            GridViewExample.DataBind();
        }
    }
}