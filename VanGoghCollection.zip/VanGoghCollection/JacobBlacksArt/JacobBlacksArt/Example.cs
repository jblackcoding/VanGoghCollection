﻿//***************************************//
//Name: Jacob Black                      //
//Project: Insert Art ASP.NET            //
//Description: This project is designed  //
//             to take user input and    //
//             display it.               //
//Date: 4/22/2017                        //
//***************************************//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JacobBlacksArt
{
    public class Example
    {
        public string PieceName { get; set; }
        public string Location { get; set; }
        public string Media { get; set; }
        public string Genre { get; set; }
        public int YearCreated { get; set; }
        public string DateAquired { get; set; }

        public static List<Example> Examples()
        {
            List<Example> listExamples = new List<Example>();

            Example example1 = new Example
            {
                PieceName = "The Starry Night",
                Location = "Museum of Art",
                Media = "oil paint",
                Genre = "landscape",
                YearCreated = 1889,
                DateAquired = DateTime.Today.ToShortDateString()
            };
            listExamples.Add(example1);

            Example example2 = new Example
            {
                PieceName = "Irises",
                Location = "J. Paul Getty Museum",
                Media = "oil paint",
                Genre = "landscape",
                YearCreated = 1889,
                DateAquired = DateTime.Today.ToShortDateString()
            };
            listExamples.Add(example2);

            return listExamples;
        }
    }
}